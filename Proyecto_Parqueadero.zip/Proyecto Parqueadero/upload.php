<?php
require 'mysqlConnect.php';
?>
<?php
if(isset($_POST['sub'])){

	$name=mysqli_real_escape_string($con,$_POST['name']);
	$slot=mysqli_real_escape_string($con,$_POST['slot']);
	$remaining_slots=mysqli_real_escape_string($con,$_POST['remaining_slots']);

	$attendant=mysqli_real_escape_string($con,$_POST['attendant']);


	   if($location==''&& $street==''&& $name=='' && $slot=='' && $remaining_slots==''){
		echo"<script>alert('please fill all field')</script>";
		echo"<script>window.open('blank.php','_self')</script>";
		exit();
	 }

	else{

		$insert="INSERT INTO `parkings` (`id`, `location`, `name`, `slot` ,`remaining_slots`,`attendant`) VALUES (NULL, '$location',  '$name', '$slot','$remaining_slots','$attendant');";
		$run_insert=mysqli_query($con,$insert);
		if($run_insert){
			echo"<script>alert('Añadido Exitosamente')</script>";
			echo"<script>window.open('blank.php','_self')</script>";

		}
		else{
			echo"<script>alert('Intenta de nuevo hubo un error')</script>";
			echo"<script>window.open('blank.php','_self')</script>";
		}
}}

?>
