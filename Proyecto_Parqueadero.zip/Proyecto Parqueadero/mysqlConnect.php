<?php

$con=mysqli_connect("localhost","root","","smart_users") OR die('Network connection error. Check connection then reload');
/*
$con=mysqli_connect("localhost","root","pass123","smart_users") OR die('Network connection error. Check connection then reload');
*/
 ?>
